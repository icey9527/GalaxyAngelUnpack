import struct
import sys
from PIL import Image
import numpy as np
import argparse

def compress_alpha(a):
    """PS2专用Alpha压缩：将0-255压缩到0-128范围"""
    return min(int(round((a + 1) / 2)), 128) if a > 0 else 0

def png_to_4bpp_agi(png_path, agi_path):
    try:
        # 1. 加载并预处理图像（强制RGBA模式，宽度调整为偶数）
        img = Image.open(png_path).convert('RGBA')
        width, height = img.size
        
        # 处理奇数宽度：右侧填充透明像素
        if width % 2 != 0:
            new_width = width + 1
            new_img = Image.new('RGBA', (new_width, height), (0, 0, 0, 0))
            new_img.paste(img, (0, 0))
            img = new_img
            width = new_width

        # 2. 分离RGBA通道并转换为NumPy数组
        img_array = np.array(img)
        r = img_array[..., 0]
        g = img_array[..., 1]
        b = img_array[..., 2]
        a = img_array[..., 3]

        # 3. 使用PIL内置方法生成16色调色板（严格量化）
        quantized = Image.fromarray(img_array[..., :3]).quantize(
            colors=16,
            method=Image.MEDIANCUT,
            dither=Image.NONE
        )
        palette = quantized.getpalette()[:16*3]  # 直接截取前48字节

        # 4. 计算每个调色板项的Alpha平均值
        palette_indices = np.array(quantized)
        palette_alphas = [[] for _ in range(16)]
        for y in range(height):
            for x in range(width):
                idx = palette_indices[y, x]
                if idx < 16:
                    palette_alphas[idx].append(a[y, x])

        # 5. 构建AGI调色板（RGBA四通道）
        agi_palette = bytearray()
        for i in range(16):
            # 处理颜色值
            r_val = palette[i*3] if i*3 < len(palette) else 0
            g_val = palette[i*3+1] if i*3+1 < len(palette) else 0
            b_val = palette[i*3+2] if i*3+2 < len(palette) else 0
            
            # 计算压缩后的Alpha值
            alpha_values = palette_alphas[i]
            avg_alpha = int(np.mean(alpha_values)) if alpha_values else 0
            a_val = compress_alpha(avg_alpha)
            
            agi_palette.extend([r_val, g_val, b_val, a_val])

        # 6. 生成4bpp像素数据（每字节存储两个4位索引）
        agi_pixels = bytearray()
        for y in range(height):
            row = palette_indices[y]
            for x in range(0, width, 2):
                # 处理奇数宽度最后一个像素
                idx1 = min(row[x], 15)
                idx2 = min(row[x+1], 15) if x+1 < width else idx1
                agi_pixels.append((idx1 << 4) | idx2)

        # 7. 构建文件头
        header = bytearray(48)
        header[0x00:0x04] = b'\x20\x00\x00\x00'
        header[0x04:0x06] = b'\x01\x00'
        header[0x06:0x08] = b'\x01\x00'
        header[0x08:0x0C] = struct.pack('<I', 0x30)
        header[0x0E] = 0x14
        header[0x10:0x12] = struct.pack('<H', 8)
        header[0x12:0x14] = struct.pack('<H', height)
        header[0x18:0x1A] = struct.pack('<H', width)
        header[0x1A:0x1C] = struct.pack('<H', height)
        header[0x1C:0x20] = struct.pack('<I', len(agi_pixels) + 0x30)
        header[0x24] = 1
        header[0x2C:0x2E] = struct.pack('<H', 8)
        header[0x2E:0x30] = struct.pack('<H', 2)

        # 8. 写入文件
        with open(agi_path, 'wb') as f:
            f.write(header)
            f.write(agi_pixels)
            f.write(agi_palette)
        print(f"转换成功: {png_path} -> {agi_path}")

    except Exception as e:
        print(f"转换失败: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('input', help='输入PNG文件路径')
    parser.add_argument('output', help='输出AGI文件路径')
    args = parser.parse_args()
    png_to_4bpp_agi(args.input, args.output)